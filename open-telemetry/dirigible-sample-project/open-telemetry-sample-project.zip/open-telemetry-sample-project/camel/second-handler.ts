export function onMessage(message: any) {
    console.log('Second handler is called.');

    return message;
}
