import { APIClient } from "../api-client"

console.log('Executing job handler...');

const apiClient = new APIClient();
const httpResponse = apiClient.getData();

console.log(`Job handler: received status code [${httpResponse.statusCode}] and body [${httpResponse.text}]`);
