import { client, HttpClientResponse } from "sdk/http";

export class APIClient {

    public getData(): HttpClientResponse {
        const url = "https://httpbin.org/json";
        return this.getDataFromUrl(url);
    }

    public getDataFromUrl(url: string): HttpClientResponse {
        console.log(`Sending request to ${url}...`);

        const httpResponse = client.get(url);
        console.log(`Received status code [${httpResponse.statusCode}] and body [${httpResponse.text}]`);

        return httpResponse;
    }


}
