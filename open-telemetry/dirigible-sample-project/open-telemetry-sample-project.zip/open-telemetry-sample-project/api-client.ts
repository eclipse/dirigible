import { client, HttpClientResponse } from "sdk/http";

export class APIClient {

    public getData(): HttpClientResponse {
        const url = "https://httpbin.org/json";
        console.log(`Sending request to ${url}...`);

        const httpResponse = client.get(url);

        console.log(`Received status code [${httpResponse.statusCode}] and body [${httpResponse.text}]`);
        return httpResponse;
    }


}
