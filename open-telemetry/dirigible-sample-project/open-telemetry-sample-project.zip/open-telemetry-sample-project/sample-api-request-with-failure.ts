import { client, response } from "sdk/http";

const url = "https://invalid.host.com/json";
console.log(`Sending request to ${url}...`);

const httpResponse = client.get(url);

console.log(`Received status code [${httpResponse.statusCode}] and body [${httpResponse.text}]`);

response.println(httpResponse.text);
response.flush();
response.close();

"This is a result of the script execution";