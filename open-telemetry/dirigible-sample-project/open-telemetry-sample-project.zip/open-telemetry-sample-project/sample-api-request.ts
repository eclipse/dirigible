import { response } from "sdk/http";
import { APIClient } from "./api-client"

const url = "https://httpbin.org/json";
console.log(`Sending request to ${url}...`);

const apiClient = new APIClient();
const httpResponse = apiClient.getData();

console.log(`Received status code [${httpResponse.statusCode}] and body [${httpResponse.text}]`);

response.println(httpResponse.text);
response.flush();
response.close();

"This is a result of the script execution";