/*eslint-env node */

exports.getItem = function() {
	var item = {
	    "name": "Discover",
	    "link": "#/discover"
	};
	return item;
};

exports.getOrder = function() {
	return 1;
};