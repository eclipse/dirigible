/*eslint-env node */

exports.getItem = function() {
	var item = {
	    "name": "Operate",
	    "link": "#/operate"
	};
	return item;
};

exports.getOrder = function() {
	return 3;
};