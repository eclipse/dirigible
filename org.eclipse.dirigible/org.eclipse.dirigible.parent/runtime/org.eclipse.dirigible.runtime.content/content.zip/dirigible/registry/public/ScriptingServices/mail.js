exports.sendMail = function(from, to, subject, content) {
	return mail.sendMail(from, to, subject, content);
};
