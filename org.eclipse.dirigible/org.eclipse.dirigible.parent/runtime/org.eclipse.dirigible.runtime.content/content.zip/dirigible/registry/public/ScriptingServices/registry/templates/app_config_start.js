/*globals registryApp */
/*eslint-env jquery */

registryApp.config(/* @callback */ function($routeProvider) {

