/* globals $ */
/* eslint-env node, dirigible */

var systemLib = require('system');
systemLib.println("Hello World!");
