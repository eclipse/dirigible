/* globals $ */
/* eslint-env node, dirigible */

console.log("Hello World!");
