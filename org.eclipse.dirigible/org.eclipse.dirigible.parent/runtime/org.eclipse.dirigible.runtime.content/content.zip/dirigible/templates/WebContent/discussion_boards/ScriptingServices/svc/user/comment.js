#set( $D = '$' )
/* globals ${D} */
/* eslint-env node, dirigible */
"use strict";

require("${packageName}/lib/comments_service_lib").get().service();
