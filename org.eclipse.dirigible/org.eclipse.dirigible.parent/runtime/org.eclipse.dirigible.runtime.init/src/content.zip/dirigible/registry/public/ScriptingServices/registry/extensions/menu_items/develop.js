/*eslint-env node */

exports.getItem = function() {
	var item = {
	    "name": "Develop",
	    "link": "#/develop"
	};
	return item;
};

exports.getOrder = function() {
	return 0;
};