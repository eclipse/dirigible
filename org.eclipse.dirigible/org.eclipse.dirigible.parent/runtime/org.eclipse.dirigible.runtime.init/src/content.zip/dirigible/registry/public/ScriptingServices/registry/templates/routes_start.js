	/*globals $routeProvider */
	/*eslint-env jquery */

	$routeProvider.when('/home', {
      controller: 'HomeCtrl',
      templateUrl: 'templates/home/home.html'
    })
