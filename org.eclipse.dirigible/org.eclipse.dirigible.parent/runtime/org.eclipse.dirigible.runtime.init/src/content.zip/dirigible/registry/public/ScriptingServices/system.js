exports.print = function(s){
	out.print(s + '');
};

exports.println = function(s){
	out.println(s + '');
};
