/* globals $ */
/* eslint-env node, dirigible */

$.getResponse().setContentType("text/html; charset=UTF-8");
$.getResponse().setCharacterEncoding("UTF-8");
$.getResponse().getWriter().println("Hello World!");
$.getResponse().getWriter().flush();
