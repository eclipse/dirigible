/* globals $ */
/* eslint-env node, dirigible */

var session = require('net/http/session');
session.invalidate();
